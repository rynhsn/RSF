﻿namespace BlazorMenu.Models
{
    public class LoginModel
    {
        public string CompanyId { get; set; }
        public string UserId { get; set; }
        public string Password { get; set; }
    }
}
