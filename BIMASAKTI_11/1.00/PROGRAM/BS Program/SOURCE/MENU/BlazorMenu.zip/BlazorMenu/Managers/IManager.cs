﻿namespace BlazorMenu.Managers
{
    public interface IManager
    {
    }
}
