﻿using R_CommonFrontBackAPI.Log;

namespace GLTR00100COMMON
{
    public class LoggerGLTR00100Print : R_NetCoreLoggerBase<LoggerGLTR00100Print>
    {
    }
}
