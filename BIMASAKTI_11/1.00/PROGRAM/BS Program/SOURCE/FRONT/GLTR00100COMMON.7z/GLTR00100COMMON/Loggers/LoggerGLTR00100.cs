﻿using R_CommonFrontBackAPI.Log;

namespace GLTR00100COMMON
{
    public class LoggerGLTR00100 : R_NetCoreLoggerBase<LoggerGLTR00100>
    {
    }
}
