﻿namespace GLTR00100COMMON
{
    public class ContextConstant
    {

    }
}
