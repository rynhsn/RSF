namespace GSM05000FrontResources
{
    public class Resources_Dummy_Class
    {
    }
}