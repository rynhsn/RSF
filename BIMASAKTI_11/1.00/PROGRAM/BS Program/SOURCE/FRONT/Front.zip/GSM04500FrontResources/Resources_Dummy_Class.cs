﻿using System;

namespace GSM04500FrontResources
{
    public class Resources_Dummy_Class
    {
    }
}