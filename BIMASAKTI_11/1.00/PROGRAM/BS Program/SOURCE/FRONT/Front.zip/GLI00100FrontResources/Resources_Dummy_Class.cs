namespace GLI00100FrontResources
{
    public class Resources_Dummy_Class
    {
    }
}