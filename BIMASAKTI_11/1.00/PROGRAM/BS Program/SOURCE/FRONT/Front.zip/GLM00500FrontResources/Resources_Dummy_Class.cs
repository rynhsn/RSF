namespace GLM00500FrontResources
{
    public class Resources_Dummy_Class
    {
    }
}