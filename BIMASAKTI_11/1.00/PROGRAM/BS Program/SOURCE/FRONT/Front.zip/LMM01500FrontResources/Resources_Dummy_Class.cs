﻿namespace LMM01500FrontResources
{
    public class Resources_Dummy_Class
    {

    }
}
