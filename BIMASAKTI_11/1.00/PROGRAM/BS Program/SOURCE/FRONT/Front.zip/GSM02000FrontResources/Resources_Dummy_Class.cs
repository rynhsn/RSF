namespace GSM02000FrontResources
{
    public class Resources_Dummy_Class
    {
    }
}