namespace APR00500Common.DTOs
{
    public class APR00500FunctDTO
    {
        public string CCODE { get; set; } = "";
        public string CDESCRIPTION { get; set; } = "";
    }
}