﻿namespace APR00500Common.Params
{
    public class APR00500PeriodParam
    {
        public string CYEAR { get; set; } = "";
    }
}