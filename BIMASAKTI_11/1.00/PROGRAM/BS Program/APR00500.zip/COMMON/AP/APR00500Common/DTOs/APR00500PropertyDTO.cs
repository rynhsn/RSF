﻿using System;

namespace APR00500Common.DTOs
{
    public class APR00500PropertyDTO
    {
        public string CPROPERTY_ID { get; set; } = "";
        public string CPROPERTY_NAME { get; set; } = "";
    }
}