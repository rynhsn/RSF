namespace APR00500Common.DTOs.Print
{
    public class APR00500PrintBaseHeaderLogoDTO
    {
        public byte[] BLOGO { get; set; }
    }
}