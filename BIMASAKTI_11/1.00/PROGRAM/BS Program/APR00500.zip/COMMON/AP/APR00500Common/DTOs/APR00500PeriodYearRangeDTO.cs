namespace APR00500Common.DTOs
{
    public class APR00500PeriodYearRangeDTO
    {
        public int IMIN_YEAR { get; set; }
        public int IMAX_YEAR { get; set; }
    }
}