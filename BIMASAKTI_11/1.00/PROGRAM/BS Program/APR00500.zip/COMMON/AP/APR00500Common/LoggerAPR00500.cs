﻿using System;
using R_CommonFrontBackAPI.Log;

namespace APR00500Common
{
    public class LoggerAPR00500 : R_NetCoreLoggerBase<LoggerAPR00500>
    {
    }
}