namespace APR00500Common.DTOs
{
    public class APR00500PeriodDTO
    {
        public string CCYEAR { get; set; } = "";
        public string CPERIOD_NO { get; set; } = "";
        public string CSTART_DATE { get; set; } = "";
        public string CEND_DATE { get; set; } = "";
    }
}