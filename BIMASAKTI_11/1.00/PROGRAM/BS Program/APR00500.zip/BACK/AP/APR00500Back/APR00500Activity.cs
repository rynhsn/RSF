using R_OpenTelemetry;

namespace APR00500Back;

public class APR00500Activity : R_ActivitySourceBase
{
}