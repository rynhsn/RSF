﻿using System;

namespace APR00500BackResources
{
    public class Resources_Dummy_Class
    {
    }
}