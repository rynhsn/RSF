﻿using System;

namespace APR00500FrontResources
{
    public class Resources_Dummy_Class
    {
    }
}