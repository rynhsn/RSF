﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL01100ParameterDTO
    {
        public string CPARAMETER_ID { get; set; } = "";
        public string CPROGRAM_ID { get; set; } = "";
        public string CSEARCH_TEXT { get; set; } = "";
        public string CCOMPANY_ID { get; set; }
    }

}
