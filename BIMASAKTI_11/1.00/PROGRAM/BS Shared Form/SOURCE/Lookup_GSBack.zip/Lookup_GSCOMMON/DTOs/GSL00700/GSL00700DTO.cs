﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL00700DTO
    {
        public string CDEPT_CODE { get; set; }
        public string CDEPT_NAME { get; set; }
        public string CCENTER_CODE { get; set; }
        public string CCENTER_NAME { get; set; }

    }
}
