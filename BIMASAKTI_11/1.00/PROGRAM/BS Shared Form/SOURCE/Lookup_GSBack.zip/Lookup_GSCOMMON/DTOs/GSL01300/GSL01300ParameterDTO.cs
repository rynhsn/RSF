﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL01300ParameterDTO
    {
        public string CBANK_TYPE { get; set; } = "";
        public string CCB_CODE { get; set; } = "";
        public string CDEPT_CODE { get; set; } = "";
        public string CSEARCH_TEXT { get; set; } = "";
        public string CCOMPANY_ID { get; set; }
        public string CUSER_ID { get; set; }
    }

}
