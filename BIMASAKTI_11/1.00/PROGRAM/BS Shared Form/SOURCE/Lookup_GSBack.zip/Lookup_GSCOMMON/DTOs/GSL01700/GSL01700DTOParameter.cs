﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL01700DTOParameter
    {
        public string CCOMPANY_ID { get; set; }
        public string CUSER_ID { get; set; }
        public string CRATETYPE_CODE { get; set; } = "";
        public string CRATE_DATE { get; set; } = "";

    }
}
