﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL00110ParameterDTO
    {
        public string CCOMPANY_ID { get; set; }
        public string CUSER_ID { get; set; }
        public string CTAX_DATE { get; set; }
        public string CSEARCH_TEXT { get; set; } = "";
    }

}
