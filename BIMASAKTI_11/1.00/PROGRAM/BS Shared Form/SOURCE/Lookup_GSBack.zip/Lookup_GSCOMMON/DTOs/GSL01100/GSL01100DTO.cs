﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL01100DTO
    {
        public string CUSER_ID { get; set; }
        public string CUSER_NAME { get; set; }
    }
}
