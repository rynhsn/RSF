﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL01500ResultDetailDTO
    {
        public string CSEQUENCE { get; set; }
        public string CCASH_FLOW_GROUP_CODE { get; set; }
        public string CCASH_FLOW_CODE { get; set; }
        public string CCASH_FLOW_NAME { get; set; }
        public string CCASH_FLOW_TYPE { get; set; }
        public string CCASH_FLOW_TYPE_DESCR { get; set; }
    }
}
