﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL01500ResultGroupDTO
    {
        public string CCASH_FLOW_GROUP_CODE { get; set; }
        public string CCASH_FLOW_GROUP_NAME { get; set; }
    }
}
