﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL01500DTO
    {
        public string CCASH_FLOW_GROUP_CODE { get; set; }
        public string CCASH_FLOW_CODE { get; set; }
        public string CCASH_FLOW_NAME { get; set; }
    }
}
