﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL00600DTO
    {
        public string CUNIT_TYPE_CATEGORY_ID { get; set; }
        public string CUNIT_TYPE_CATEGORY_NAME { get; set; }
    }
}
