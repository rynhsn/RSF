﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL00510ParameterDTO
    {
        public string CGLACCOUNT_TYPE { get; set; } = "";
        public string CCOMPANY_ID { get; set; }
        public string CUSER_ID { get; set; }
        public string CSEARCH_TEXT { get; set; } = "";
        public bool LINACTIVE_COA { get; set; } = false;
    }

}
