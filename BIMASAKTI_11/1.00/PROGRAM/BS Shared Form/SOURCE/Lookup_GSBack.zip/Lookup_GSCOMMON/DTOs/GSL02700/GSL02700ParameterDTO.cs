﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL02700ParameterDTO
    {
        public string CPROPERTY_ID { get; set; } = "";
        public bool LEVENT { get; set; }
        public string CSEARCH_TEXT { get; set; } = "";
    }

}
