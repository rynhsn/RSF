﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL01600DTO
    {
        public string CCASH_FLOW_GROUP_CODE { get; set; }
        public string CCASH_FLOW_GROUP_NAME { get; set; }
        public string CCASH_FLOW_GROUP_TYPE_DESCR { get; set; }
    }
}
