﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL01000ParameterDTO
    {
        public string CSEARCH_TEXT { get; set; } = "";
    }

}
