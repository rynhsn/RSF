﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL01300DTO
    {
        public string CCB_ACCOUNT_NO { get; set; }
        public string CCB_ACCOUNT_NAME { get; set; }
    }
}
