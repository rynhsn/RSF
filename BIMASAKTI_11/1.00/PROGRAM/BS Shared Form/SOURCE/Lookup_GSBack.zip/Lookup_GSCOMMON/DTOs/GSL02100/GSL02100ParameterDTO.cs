﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL02100ParameterDTO
    {
        public string CCOMPANY_ID { get; set; }
        public string CPROPERTY_ID { get; set; } = "";
        public string CSEARCH_TEXT { get; set; } = "";
        public string CUSER_ID { get; set; }
    }

}
