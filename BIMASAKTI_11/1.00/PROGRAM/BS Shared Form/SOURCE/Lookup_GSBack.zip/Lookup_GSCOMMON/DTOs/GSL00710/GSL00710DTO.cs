﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL00710DTO
    {
        public string CCOMPANY_ID { get; set; }
        public string CPROPERTY_ID { get; set; }
        public string CDEPT_CODE { get; set; }
        public string CDEPT_NAME { get; set; }
    }
}
