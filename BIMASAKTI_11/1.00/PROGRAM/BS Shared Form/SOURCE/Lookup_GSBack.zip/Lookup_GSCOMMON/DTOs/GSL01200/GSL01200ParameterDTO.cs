﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL01200ParameterDTO
    {
        public string CCB_TYPE { get; set; } = "";
        public string CBANK_TYPE { get; set; } = "";
        public string CSEARCH_TEXT { get; set; } = "";
        public string CCOMPANY_ID { get; set; }
        public string CUSER_ID { get; set; }
    }

}
