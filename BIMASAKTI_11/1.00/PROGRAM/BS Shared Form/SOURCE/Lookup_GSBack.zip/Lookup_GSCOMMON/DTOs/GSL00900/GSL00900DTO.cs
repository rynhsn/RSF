﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL00900DTO
    {
        public string CCENTER_CODE { get; set; }
        public string CCENTER_NAME { get; set; }
    }
}
