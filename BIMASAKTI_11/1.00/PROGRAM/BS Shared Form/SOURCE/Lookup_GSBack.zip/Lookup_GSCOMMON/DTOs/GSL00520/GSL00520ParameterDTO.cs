﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL00520ParameterDTO
    {
        public string CSEARCH_TEXT { get; set; } = "";
        public string CCOMPANY_ID { get; set; }
        public string CGOA_CODE { get; set; } = "";
    }

}
