﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL01400ParameterDTO
    {
        public string CPROPERTY_ID { get; set; } = "";
        public string CCHARGES_TYPE_ID { get; set; } = "";
        public string CSEARCH_TEXT { get; set; } = "";
        public string CCOMPANY_ID { get; set; }
        public string CUSER_LOGIN_ID { get; set; }
    }

}
