﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL01702DTO
    {
        public string CLOCAL_CURRENCY { get; set; }
        public string CLOCAL_CURRENCY_NAME { get; set; }
        public string CBASE_CURRENCY { get; set; }
        public string CBASE_CURRENCY_NAME { get; set; }
    }
}
