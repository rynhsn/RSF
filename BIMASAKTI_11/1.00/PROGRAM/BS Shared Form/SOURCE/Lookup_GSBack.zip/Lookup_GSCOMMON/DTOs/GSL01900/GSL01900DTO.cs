﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL01900DTO
    {
        public string CLOB_CODE { get; set; }
        public string CLOB_NAME { get; set; }
    }
}
