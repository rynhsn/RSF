﻿using System;

namespace Lookup_GSCOMMON.DTOs
{
    public class GSL02000DTO
    {
        public string CCODE_COUNTRY { get; set; }
        public string CCODE_PROVINCE { get; set; }
        public string CCODE { get; set; }
        public string CNAME_COUNTRY { get; set; }
        public string CNAME_PROVINCE { get; set; }
        public string CNAME { get; set; }
    }
}
