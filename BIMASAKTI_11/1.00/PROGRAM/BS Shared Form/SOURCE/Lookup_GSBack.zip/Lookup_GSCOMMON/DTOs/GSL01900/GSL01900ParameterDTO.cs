﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL01900ParameterDTO
    {
        public string CSEARCH_TEXT { get; set; } = "";
    }

}
