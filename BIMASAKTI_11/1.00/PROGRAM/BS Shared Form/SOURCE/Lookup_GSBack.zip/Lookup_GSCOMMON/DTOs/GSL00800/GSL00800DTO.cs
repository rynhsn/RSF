﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL00800DTO
    {
        public string CRATETYPE_CODE { get; set; }
        public string CRATETYPE_DESCRIPTION { get; set; }
    }
}
