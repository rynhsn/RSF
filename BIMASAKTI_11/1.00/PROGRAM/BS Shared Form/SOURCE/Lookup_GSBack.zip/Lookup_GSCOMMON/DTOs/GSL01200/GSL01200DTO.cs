﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL01200DTO
    {
        public string CCB_CODE { get; set; }
        public string CCB_NAME { get; set; }
    }
}
