﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL00300ParameterDTO
    {
        public string CCOMPANY_ID { get; set; } 
        public string CUSER_ID { get; set; }
        public string CSEARCH_TEXT { get; set; } = "";
    }

}
