﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL01800DTOParameter
    {
        public string CCOMPANY_ID { get; set; }
        public string CUSER_ID { get; set; }
        public string CPROPERTY_ID { get; set; } = "";
        public string CCATEGORY_TYPE { get; set; } = "";
        public string CSEARCH_TEXT { get; set; } = "";

    }
}
