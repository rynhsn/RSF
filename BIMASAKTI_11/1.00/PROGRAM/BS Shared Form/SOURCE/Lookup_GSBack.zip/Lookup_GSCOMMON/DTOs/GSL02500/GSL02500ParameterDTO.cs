﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL02500ParameterDTO
    {
        public string CDEPT_CODE { get; set; }
        public string CCB_TYPE { get; set; }
        public string CBANK_TYPE { get; set; }
        public string CSEARCH_TEXT { get; set; }
    }

}
