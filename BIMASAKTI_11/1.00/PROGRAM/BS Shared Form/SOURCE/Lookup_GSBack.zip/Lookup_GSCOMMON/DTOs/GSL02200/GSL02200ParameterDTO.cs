﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL02200ParameterDTO
    {
        public string CPROPERTY_ID { get; set; }
        public bool LAGREEMENT { get; set; }
        public string CSEARCH_TEXT { get; set; }
    }

}
