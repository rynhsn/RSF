﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL00400DTO
    {
        public string CJRNGRP_CODE { get; set; }
        public string CJRNGRP_NAME { get; set; }
        public string CJRNGRP_TYPE { get; set; }
        public bool LACCRUAL { get; set; }
    }
}
