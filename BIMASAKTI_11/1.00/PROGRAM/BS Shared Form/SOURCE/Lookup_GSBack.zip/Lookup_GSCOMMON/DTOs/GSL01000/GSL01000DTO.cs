﻿namespace Lookup_GSCOMMON.DTOs
{
    public class GSL01000DTO
    {
        public string CCOMPANY_ID { get; set; }
        public string CEMAIL_ADDRESS { get; set; }
        public string CPOSITION { get; set; }
        public string CUSER_ID { get; set; }
        public string CUSER_NAME { get; set; }
    }
}
