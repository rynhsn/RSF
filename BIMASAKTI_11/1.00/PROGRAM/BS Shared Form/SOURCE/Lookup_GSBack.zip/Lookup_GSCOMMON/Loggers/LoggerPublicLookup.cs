﻿using R_CommonFrontBackAPI.Log;

namespace Lookup_GSCOMMON.Loggers
{
    public class LoggerPublicLookup : R_NetCoreLoggerBase<LoggerPublicLookup>
    {

    }
}
