﻿namespace Lookup_GSFrontResources
{
    public class Resources_Dummy_Class
    {

    }
}
