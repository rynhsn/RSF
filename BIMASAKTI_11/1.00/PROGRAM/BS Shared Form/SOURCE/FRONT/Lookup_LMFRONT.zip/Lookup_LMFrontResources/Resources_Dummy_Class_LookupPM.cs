﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lookup_PMFrontResources
{
    public class Resources_Dummy_Class_LookupPM
    {
    }
}
